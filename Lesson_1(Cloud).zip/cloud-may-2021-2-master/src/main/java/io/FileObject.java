package io;

import java.io.Serializable;

public class FileObject implements Serializable {
    private long len;
    private byte[] data;
}
