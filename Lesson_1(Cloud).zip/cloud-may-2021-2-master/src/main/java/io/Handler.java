package io;

import java.io.*;
import java.net.Socket;

import lombok.extern.slf4j.Slf4j;
import shared.Marker;

@Slf4j
public class Handler implements Runnable, Closeable {

    private final Socket socket;
    private  String userDir;

    public Handler(Socket socket) {
        this.socket = socket;
        userDir = "folder";
    }

    @Override
    public void run() {
        try (DataInputStream is = new DataInputStream(socket.getInputStream());
             DataOutputStream os = new DataOutputStream(socket.getOutputStream())) {
            while (true) {
                String marker = is.readUTF();
                if (marker.equals(Marker.SEND_LIST_FILES.name())){
                    os.writeUTF(Marker.SEND_LIST_FILES.name());
                    os.flush();
                    File file = new File(userDir);
                    for (File f : file.listFiles()) {
                        os.writeUTF(f.getName());
                    }
                } else if (marker.equals(Marker.UPLOAD_FILE.name())) {
                    String name = is.readUTF();
                    File file = new File(userDir + "/" + name);
                    file.createNewFile();
                    FileOutputStream ofs = new FileOutputStream(file);
                    byte[] buffer = new byte[8192];
                    int i;
                    while ((i = is.read(buffer)) > 0) {
                        ofs.write(buffer, 0, i);
                    }
                    ofs.close();
                } else if (marker.equals(marker.equals(Marker.DOWNLOAD_FILE.name()))){
                    String name = is.readUTF();
                    File file = new File(userDir + "/" + name);
                    FileInputStream infs = new FileInputStream(file);

                    os.writeUTF(Marker.DOWNLOAD_FILE.name());
                    os.flush();

                    byte[] buffer = new byte[8192];
                    int i;
                    while ((i = infs.read(buffer)) > 0) {
                        os.write(buffer, 0, i);
                    }
                    os.flush();
                    infs.close();
                }
            }
        } catch (Exception e) {
            log.error("e=", e);
        }
    }

    @Override
    public void close() throws IOException {
        socket.close();
    }
}
