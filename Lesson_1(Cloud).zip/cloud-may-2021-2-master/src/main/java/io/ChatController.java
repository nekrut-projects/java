package io;

import java.io.*;
import java.net.Socket;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import lombok.extern.slf4j.Slf4j;
import shared.Marker;

@Slf4j
public class ChatController implements Initializable {

    public TextField input;
//    public ListView<String> listView;
    public ListView<String> cListView;
    public TextField cTextField;
    public Button uploadButton;
    public Button downloadButton;
    public ListView<String> sListView;
    public TextField sTextField;

    private String currentFolder = "folder2";
    private DataInputStream is;
    private DataOutputStream os;

    public void send(ActionEvent actionEvent) throws IOException {
        os.writeUTF(input.getText());
        os.flush();
        input.clear();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        try {
            Socket socket = new Socket("localhost", 8189);
            is = new DataInputStream(socket.getInputStream());
            os = new DataOutputStream(socket.getOutputStream());

            fillClientListView();

            os.writeUTF(Marker.SEND_LIST_FILES.name());

            Thread readThread = new Thread(() -> {
                try {
                    String marker = is.readUTF();
                    if (marker.equals(Marker.SEND_LIST_FILES.name())) {
                        while (true) {
                            String name = is.readUTF();
                            Platform.runLater(() -> sListView.getItems().add(name));
                        }
                    } else if (marker.equals(Marker.DOWNLOAD_FILE.name())) {
                        os.writeUTF("");
                    }
                } catch (Exception e) {
                    log.error("e=", e);
                }
            });
            readThread.setDaemon(true);
            readThread.start();
        } catch (Exception e) {
            log.error("e=", e);
        }
    }

    public void upload(ActionEvent actionEvent) throws IOException {
        String item = cListView.getSelectionModel().getSelectedItem();
        if (item == null) {
            item = cListView.getItems().get(0);
        }
        os.writeUTF(Marker.UPLOAD_FILE.name());
        os.flush();
        os.writeUTF(item);
        os.flush();
        File f = new File(currentFolder + "/" + item);
        FileInputStream inf = new FileInputStream(f);

        byte[] buffer = new byte[8192];
        int i;
        while ((i = inf.read(buffer)) > 0) {
            os.write(buffer, 0, i);
        }
        os.flush();
        os.writeUTF(Marker.SEND_LIST_FILES.name());
        inf.close();
    }

    public void download(ActionEvent actionEvent) throws IOException {
        String item = sListView.getSelectionModel().getSelectedItem();
        if (item == null) {
            item = sListView.getItems().get(0);
        }
        System.out.println(item);
        os.writeUTF(Marker.DOWNLOAD_FILE.name());
        os.flush();
        os.writeUTF(item);
        os.flush();

        File file = new File(currentFolder + "/" + item);
        file.createNewFile();
        FileOutputStream outf = new FileOutputStream(file);

        byte[] buffer = new byte[8192];
        int i;
        while ((i = is.read(buffer)) > 0) {
            outf.write(buffer, 0, i);
        }
        outf.close();
    }

    public void fillClientListView() {
        for (String f : new File(currentFolder).list()) {
            Platform.runLater(() -> cListView.getItems().add(f));
        }
    }

}
