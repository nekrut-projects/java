package shared;

public enum Marker {
    FREE, UPLOAD_FILE, DOWNLOAD_FILE, SEND_LIST_FILES
}
